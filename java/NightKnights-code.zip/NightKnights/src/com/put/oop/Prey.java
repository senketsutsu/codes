package com.put.oop;

import java.util.Random;

/**
 * An interface containing 3 functions:<br>
 * - eat (allows Prays to eat t increase their food level)<br>
 * - drink (allows Prays to eat t increase their beer level)<br>
 * - change_destination (changes destination based on current data about the pray (food and beer level)
 */


interface Prey {
    public void eat();

    public void drink(int how_hydrating);

    public void change_destination(Random rand);
}
