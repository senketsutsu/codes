package com.put.oop;


import java.awt.*;
import java.util.concurrent.Semaphore;

/**
 *
 * Library is a safe space for students and can be called a hideout.
 * Students can also multiply there by sharing their knowledge.<br>
 * Library has its:<br>
 * - size (how many people can be inside)<br>
 * - free_space (how many students can still enter the Library)<br>
 *
 */

public class Library extends Pixel{
    int size;
    int free_space;

    Library(int x, int y,int Size)
    {
        super(x,y);
        type = 4;
        size = Size;
        free_space = Size;
        name = "Library";
        semaphore = new Semaphore(Size);
    }

    void free_spaces()
    {
        free_space = semaphore.availablePermits();
        System.out.println("Empty spaces: "+free_space);
    }

    @Override
    public void paint(Graphics g)
    {
        g.setColor(new Color(161, 92, 176, 255));
        g.fillRect(this.localization[0]*5,this.localization[1]*5,5,5);
    }

    public String[] introduce_data(){
        String[] introduction = {String.valueOf(localization[0]),String.valueOf(localization[1]),String.valueOf(semaphore.availablePermits())};
        //System.out.print(introduction);
        return introduction;

    }
}
