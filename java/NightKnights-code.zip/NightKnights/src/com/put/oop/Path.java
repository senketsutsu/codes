package com.put.oop;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;


/**
 *
 * Path is a pixel on which Students can stand.
 * Path pixels construct paths on which Students travel.
 *
 */


public class Path extends Pixel{
    //List<Integer[]> destination;

    Path(int x, int y)
    {
        super(x,y);
        type = 3;
        //destination = new ArrayList<>();
    }

    @Override
    public void paint(Graphics g)
    {
        g.setColor(new Color(232, 193, 166, 77));
        g.fillRect(this.localization[0]*5,this.localization[1]*5,5,5);
    }

}
