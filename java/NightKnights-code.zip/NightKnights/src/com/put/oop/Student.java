package com.put.oop;

import java.awt.*;
import java.util.List;
import java.util.Random;

/**
 *
 * Student represents the prey in this environment.<br>
 * Each Student has: <br>
 * - beer_level (Student drinks beer from Pub to increase its beer_level, if this level is 0 then Students health decreases by 1)<br>
 * - food_level (Student eats to increase its level, if this level is 0 then Students health decreases by 1)<br>
 * - safe (Students are safe from Chaves (predators) when hiding in Library (hideout), Student cannot be attacked when there)<br>
 * - destination<br>
 * - path_to_destination<br>
 * - map<br>
 *
 */

public class Student extends Person implements Prey, Runnable{
    double beer_level;
    double food_level;
    boolean safe;
    int[] destination;
    List<Pixel> path_to_destination;
    Map map;

    Student(int ID, int Health, int Speed, int Strength, int x, int y, int Range, Map mapa)
    {
        super(ID, Health, Speed, Strength, x, y, Range);
        beer_level = 100;
        food_level = 100;
        safe = false;
        map = mapa;
        destination = new int[2];
        destination[0] = map.Libraries.get(ID%(map.Libraries.size())).localization[0];
        destination[1] = map.Libraries.get(ID%(map.Libraries.size())).localization[1];

        path_to_destination = map.find_path(map.map[destination[0]][destination[1]], map.map[localization[0]][localization[1]]);
        path_to_destination.remove(0);

        System.out.println("id:"+ID+" x/y:"+x+"/"+y);

    }

    public void eat(){
        System.out.print(id+"eating"+food_level);
        this.food_level = 100;
        System.out.println("-"+food_level);
    }

    public void drink(int how_hydrating){
        beer_level = Math.min(beer_level+how_hydrating, 10);
    }

    @Override
    public void change_destination(Random rand) {
        int[] current = {localization[0],localization[1]};

        System.out.println("f: "+food_level+" b: "+beer_level);
        if(food_level<90 && food_level+rand.nextInt(5)<beer_level+rand.nextInt(5))
        {
            int index = rand.nextInt(map.Zahirs.size());
            while(map.Zahirs.get(index).localization == current)
            {
                index = rand.nextInt(map.Zahirs.size());
            }
            destination[0] = map.Zahirs.get(index).localization[0];
            destination[1] = map.Zahirs.get(index).localization[1];
            System.out.println("Go eat "+destination[0]+"/"+destination[1]);
        }
        else{
            if(beer_level<90)
            {
                int index = rand.nextInt(map.Pubs.size());
                while(map.Pubs.get(index).localization == current)
                {
                    index = rand.nextInt(map.Pubs.size());
                }
                destination[0] = map.Pubs.get(index).localization[0];
                destination[1] = map.Pubs.get(index).localization[1];
            }
            else{
                int index = rand.nextInt(map.Libraries.size());
                while(map.Libraries.get(index).localization == current)
                {
                    index = rand.nextInt(map.Libraries.size());
                }
                destination[0] = map.Libraries.get(index).localization[0];
                destination[1] = map.Libraries.get(index).localization[1];
            }
        }
        path_to_destination = map.find_path(map.map[destination[0]][destination[1]], map.map[localization[0]][localization[1]]);
        if (path_to_destination == null)
        {
            System.out.println("f5");
            change_destination(rand);
        }
        if (path_to_destination.size()==0)
        {
            System.out.println("f6");
            change_destination(rand);

        }
        path_to_destination.remove(0);
    }

    @Override
    public void paint(Graphics g)
    {
        g.setColor(new Color(156, 255, 0));
        g.fillOval(this.localization[0]*5,this.localization[1]*5,5,5);
    }

    @Override
    public void walk() {

        if (map.map[path_to_destination.get(0).localization[0]][path_to_destination.get(0).localization[1]].semaphore.tryAcquire())
        {
            map.map[localization[0]][localization[1]].semaphore.release();

            localization[0] = path_to_destination.get(0).localization[0];
            localization[1] = path_to_destination.get(0).localization[1];
            path_to_destination.remove(0);
        }

    }

    @Override
    public void run() {
        Random rand = new Random();
        exit.set(true);

        int temp_x = localization[0];
        int temp_y = localization[1];
        int count = 0;

        while(exit.get())
        {

            if (health<=0)
            {
                System.out.println("Break");
                break;
            }


            if(destination[0] == localization[0] && destination[1] == localization[1])
            {
                if (map.map[localization[0]][localization[1]].type == 4)
                {
                    System.out.println("f1");

                    if(rand.nextInt(12)%3==0)
                    {
                        map.add_student();
                    }
                }
                if (map.map[localization[0]][localization[1]].type == 2 && beer_level<99)
                {
                    System.out.println("f2");
                    map.map[localization[0]][localization[1]].drink(this);
                }
                else {
                    System.out.println("f3");
                    if (map.map[localization[0]][localization[1]].type == 1 && food_level<99)
                    {

                        System.out.println("Try eating");
                        if (!map.map[localization[0]][localization[1]].queue().contains(this))
                        {
                            map.map[localization[0]][localization[1]].add(this);
                        }
                    }
                    else
                    {
                        change_destination(rand);
                    }
                }
            }
            else {
                if(path_to_destination.size() == 0)
                {
                    change_destination(rand);
                }
                else{
                    walk();
                    if (localization[0] == temp_x && localization[1]==temp_y)
                    {
                        count++;
                    }
                    else{
                        count = 0;
                        temp_x = localization[0];
                        temp_y = localization[1];
                    }
                }
            }

            if (count >=5)
            {
                change_destination(rand);
            }

            if (map.map[localization[0]][localization[1]].type==4)
            {
                safe = true;
            }
            else {
                safe = false;
            }


            if (!safe)
            {
                beer_level = Math.max(0, beer_level-0.1);
                food_level = Math.max(0, food_level-0.1);
                if (beer_level == 0)
                {
                    health--;
                }
                if (food_level == 0)
                {
                    health--;
                }
            }


            try {
                Thread.sleep(Long.valueOf(speed*10));
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

        }
        System.out.println("STOP: "+id);
    }

    public void stop()
    {
        exit.set(false);
    }

    public String[] introduce_data(){
        String[] introduction = {String.valueOf(id),name,String.valueOf(localization[0]),String.valueOf(localization[1]),String.valueOf(health),String.valueOf(beer_level),String.valueOf(food_level),String.valueOf(speed),String.valueOf(strength),String.valueOf(safe),zodiac_sign};
        //System.out.print(introduction);
        return introduction;

    }

}
