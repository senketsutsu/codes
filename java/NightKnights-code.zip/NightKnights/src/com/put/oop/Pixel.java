package com.put.oop;

import java.awt.*;
import java.util.List;
import java.util.concurrent.Semaphore;
import java.util.concurrent.atomic.AtomicBoolean;


/**
 *
 * Pixel represents each point on the map.<br>
 * Each pixel has:<br>
 * - localization (where is it on the map (x,y) )<br>
 * - type (type of pixel such as Pub, Zahir, Library or Path)<br>
 * - empty (states if this pixel is being used by student of not)<br>
 * - name (name of the type of pixel)<br>
 * - semaphore (semaphore for checking if pixel is empty of not)<br>
 *
 *
 */


public class Pixel {
    int[] localization;
    int type;
    AtomicBoolean empty = new AtomicBoolean(true);  // not needed since it has a semaphore
    String name;
    Semaphore semaphore;

    Pixel(int x, int y)
    {
        localization = new int[2];
        localization[0] = x;
        localization[1] = y;
        type = 0;
        empty.set(true);
        name = "Pixel";
        semaphore = new Semaphore(1);
    }

    public void isEmpty(){

        if(empty.get()){
            System.out.println("Empty");
        }else{
            System.out.println("Not empty");
        }

    }

    public int getType()
    {
        return(type);
    }

    void free_spaces()
    {
        System.out.println("cannot");
    }

    public void add(Student id){
        System.out.println("cannot");
    }

    public void drink(Student a){}

    public List<Student> queue(){return null;}

    public void paint(Graphics g)
    {
        g.setColor(new Color(255, 255, 255, 255));
        g.fillRect(this.localization[0],this.localization[1],10,10);
    }

    public String[] introduce_data(){
        String[] introduction = {};
        //System.out.print(introduction);
        return introduction;

    }

}
