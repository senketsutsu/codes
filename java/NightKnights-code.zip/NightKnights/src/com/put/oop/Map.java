package com.put.oop;

import java.util.*;
import java.lang.Math;
import java.util.Random;


/**
 *
 * Student represents the prey in this environment.<br>
 * Map has:<br>
 * - size (number of pixels in horisontal and vertical)<br>
 * - num_people (number of all people existing fom the beggining)<br>
 * - map (matrix representing the map)<br>
 * - Pubs (list of all Pubs in the Map)<br>
 * - Zahirs (list of all Zahirs in the Map)<br>
 * - Libraries (list of all Libreries in the Map)<br>
 * - Paths (map matrix showing paths all over the map)<br>
 * - Path_list (list of all Path Pixels in the map)<br>
 * - Student_list (list of all Students in the map)<br>
 * - Chav_list (list of all Chavs in the map)<br>
 *
 */


public class Map {
    int size;
    int num_people;
    Pixel[][] map;
    List<Pixel> Pubs;
    List<Pixel> Zahirs;
    List<Pixel> Libraries;
    Pixel[][] Paths;
    List<Pixel> Path_list;
    List<Student> Student_list;
    List<Chav> Chav_list;

    Map(int Size, int number_of_students, int number_of_chavs)
    {
        size = Size;
        map = new Pixel[size][size];
        Paths = new Pixel[size][size];
        Pubs = new ArrayList<Pixel>();
        Zahirs = new ArrayList<Pixel>();
        Libraries = new ArrayList<Pixel>();
        Path_list = new ArrayList<Pixel>();
        Chav_list = new ArrayList<Chav>();
        Student_list = new ArrayList<Student>();

        // generate map
        for(int i = 0; i<size; i++)
        {
            for (int j = 0; j<size; j++)
            {
                map[i][j] = new Pixel(i,j);
                Paths[i][j] = new Pixel(i,j);
            }
        }

        num_people = 0;

        // add places
        Boolean added = false;
        Random rand = new Random();
        int range = rand.nextInt(3);
        for (int i=0; i<5+range ; i++)
        {
            while(!added)
            {
                added = add(new Pub(rand.nextInt(size),rand.nextInt(size),1+rand.nextInt(3)));
            }
            added = false;
        }
        range = rand.nextInt(3);
        for (int i=0; i<5+range ; i++)
        {
            while(!added)
            {
                added = add(new Zahir(rand.nextInt(size),rand.nextInt(size)));
            }
            added = false;
        }
        range = rand.nextInt(3);
        for (int i=0; i<5+range ; i++)
        {
            while(!added)
            {
                added = add(new Library(rand.nextInt(size),rand.nextInt(size),1+rand.nextInt(3)));
            }
            added = false;
        }

        // add places to lists
        for (int i=0; i<size;i++)
        {
            for(int j=0; j<size;j++)
            {
                switch (map[i][j].type){
                    case 1:
                        Zahirs.add(map[i][j]);
                        break;
                    case 2:
                        Pubs.add(map[i][j]);
                        break;
                    case 3:
                        Path_list.add(map[i][j]);
                        break;
                    case 4:
                        Libraries.add(map[i][j]);
                        break;
                }
            }
        }

        // add paths

        for (int i = 0; i < Libraries.size(); i++) {
            for (int j = 0; j < Pubs.size(); j++) {
                add_path(Libraries.get(i),Pubs.get(j));
                for (int k = 0; k < Zahirs.size(); k++) {
                    add_path(Libraries.get(i),Zahirs.get(k));
                    add_path(Pubs.get(j),Zahirs.get(k));
                }
            }
        }

        for (int i = 0; i < Libraries.size(); i++) {
            for (int j = 0; j < Libraries.size(); j++) {
                add_path(Libraries.get(i),Libraries.get(j));
            }
        }
        for (int i = 0; i < Zahirs.size(); i++) {
            for (int j = 0; j < Zahirs.size(); j++) {
                add_path(Zahirs.get(i),Zahirs.get(j));
            }
        }
        for (int i = 0; i < Pubs.size(); i++) {
            for (int j = 0; j < Pubs.size(); j++) {
                add_path(Pubs.get(i),Pubs.get(j));
            }
        }

        for (int i=0; i<size;i++)
        {
            for(int j=0; j<size;j++)
            {
                if(Paths[i][j].type == 3)
                {
                    Path_list.add(Paths[i][j]);
                }
            }
        }

        List<Pixel> testFind = find_path(Libraries.get(0),Pubs.get(0));


        // add students
        for (int i=0;i<number_of_students;i++)
        {
            add_student();
        }

        // add chavs
        for (int i=0;i<number_of_chavs;i++)
        {
            add_chav();
        }


    }

    Boolean add(Pixel a)
    {
        if(a.localization[0]<size && a.localization[1]<size)
        {
            if(map[a.localization[0]][a.localization[1]].type == 0) {
                map[a.localization[0]][a.localization[1]] = a;
                return true;
            }
        }
        return false;
    }

    void add_student(){
        Random rand = new Random();
        int id=0;
        for(int i=0;i<Student_list.size();i++){
            id = Math.max(id, Student_list.get(i).id);
        }
        for(int i=0;i<Chav_list.size();i++){
            id = Math.max(id, Chav_list.get(i).id);
        }
        id++;
        //Student x = new Student(id, 10,6+rand.nextInt(8),4+rand.nextInt(5),Libraries.get(id%Libraries.size()).localization[0],Libraries.get(id%Libraries.size()).localization[1],size,10,10 );
        Student x = new Student(id, 10,8+rand.nextInt(10),2+rand.nextInt(5),Path_list.get(id).localization[0],Path_list.get(id).localization[1],size, this );
        Thread t = new Thread(x);
        t.start();
        Student_list.add(x);
        num_people++;
    }

    void add_chav(){
        Random rand = new Random();
        int id=0;
        for(int i=0;i<Student_list.size();i++){
            id = Math.max(id, Student_list.get(i).id);
        }
        for(int i=0;i<Chav_list.size();i++){
            id = Math.max(id, Chav_list.get(i).id);
        }
        id++;
        Chav x = new Chav(id,10,4+rand.nextInt(10),6+rand.nextInt(5),rand.nextInt(size),rand.nextInt(size), size, 1+rand.nextInt(10), this);
        Thread t = new Thread(x);
        t.start();
        Chav_list.add(x);
        num_people++;
    }

    void print()
    {
        System.out.print("  ");
        for (int i=0;i<size;i++)
        {
            System.out.print(i+" ");
        }
        System.out.print("\n");
        for (int i=0;i<size;i++)
        {
            System.out.print((i)+ " ");
            for (int j=0;j<size;j++)
            {
                System.out.print(map[j][i].type+" ");
            }
            System.out.print("\n");
        }
    }

    void print_paths()
    {
        System.out.print("  ");
        for (int i=0;i<size;i++)
        {
            System.out.print(i+" ");
        }
        System.out.print("\n");
        for (int i=0;i<size;i++)
        {
            System.out.print((i)+ " ");
            for (int j=0;j<size;j++)
            {
                System.out.print(Paths[j][i].type+" ");
            }
            System.out.print("\n");
        }
    }

    void add_path(Pixel current, Pixel destination)
    {
        List<Integer[]> visited = new ArrayList<>();
        Boolean reached = false;
        Integer x = current.localization[0];
        Integer y = current.localization[1];
        Integer[] location = {x,y};
        Paths[x][y] = new Path(x,y);
        List<String> found = new ArrayList<String>();
        List<Pixel> test_visited = new ArrayList<Pixel>();

        if (!(current.localization).equals(destination.localization))
        {
            while(!reached)
            {
                found = new ArrayList<String>();
                test_visited = new ArrayList<Pixel>();
                find_path2(destination,test_visited,map[x][y],found);
                if(found.contains("yes"))
                {
                    reached = true;
                    return;
                }

                 if (Math.abs(x-destination.localization[0]) >= Math.abs(y-destination.localization[1]))
                 {
                     if(x - destination.localization[0] >=0)
                     {
                         x-=1;
                     }
                     else{
                         x+=1;
                     }
                 }
                 else{
                     if(y - destination.localization[1] >=0)
                     {
                         y-=1;
                     }
                     else{
                         y+=1;
                     }
                 }

                 //System.out.println(x+" "+y);
                 Paths[x][y] = new Path(x,y);

                 if(x==destination.localization[0] && y==destination.localization[1]){
                     reached = true;
                     return;
                 }

            }
        }

    }

    List<Pixel> find_path(Pixel from, Pixel to)
    {
        List<Pixel> testFind = find_path_part(to,new ArrayList<Pixel>(),from,new ArrayList<Pixel>());

        if (testFind == null)
        {
            return null;
        }

        testFind.remove(0);
        testFind.add(from);

        return testFind;
    }

    List<Pixel> find_path_part(Pixel destination, List<Pixel> visited, Pixel current, List<Pixel> Final)
    {
        Pixel current2 = Paths[current.localization[0]][current.localization[1]];
        Pixel destination2 = Paths[destination.localization[0]][destination.localization[1]];

        if(current2.equals(destination2))
        {
            List<Pixel> y = new ArrayList<>();
            y.add(destination);
            return y;
        }

        if(current2.type==3) {
            visited.add(current2);
            //System.out.println(visited.size());
            Pixel x;
            List<Pixel> y;

            for (int i = -1; i <= 1; i++) {
                for (int j = -1; j <= 1; j++) {
                    if(i*j!=0)
                    {
                        continue;
                    }
                    x = Paths[Math.min(Math.max(current2.localization[0] + i, 0), size - 1)][Math.min(Math.max(current2.localization[1] + j, 0), size - 1)];
                    //System.out.println(x.localization[0]+ " " + x.localization[1]);
                    if (!visited.contains(x)) {
                        y = find_path_part(destination2, visited, x, Final);
                        if(y != null)
                        {
                            y.add(x);
                            return y;
                        }
                    }
                }
            }
        }

        return null;
    }

    void find_path2(Pixel destination, List<Pixel> visited, Pixel current, List<String> found)
    {
        Pixel current2 = Paths[current.localization[0]][current.localization[1]];
        Pixel destination2 = Paths[destination.localization[0]][destination.localization[1]];


        if(current2.equals(destination2))
        {
            found.add("yes");
            return;
        }

        if(current2.type==3) {
            visited.add(current2);
            //System.out.println(visited.size());
            Pixel x;



            for (int i = -1; i <= 1; i++) {
                for (int j = -1; j <= 1; j++) {
                    if(i*j!=0)
                    {
                        continue;
                    }
                    x = Paths[Math.min(Math.max(current2.localization[0] + i, 0), size - 1)][Math.min(Math.max(current2.localization[1] + j, 0), size - 1)];
                    //System.out.println(x.localization[0]+ " " + x.localization[1]);
                    if (!visited.contains(x)) {
                        find_path2(destination2, visited, x, found);
                    }
                }
            }
        }
    }

    String[][] generate_table(){
        String[][] table = new String[size][size+1];
        for(int i = 0; i<size; i++)
        {
            for (int j = 0; j<size+1; j++)
            {
                table[i][j] = "";
            }
        }
        for (int i = 0; i < size; i++) {
            table[i][0] = Integer.toString(i+1);
        }


        // paths
        for (int i=0;i<size;i++)
        {
            for (int j=0;j<size;j++)
            {
                if(Paths[j][i].type == 3)
                {
                    //table[i][j+1] = "∙";
                    table[i][j+1] = "#";
                }
            }
        }

        // pubs, zahirs, libraries
        for (int i=0;i<size;i++)
        {
            for (int j=0;j<size;j++)
            {
                // zahir
                if(map[j][i].type == 1)
                {
                    table[i][j+1] = "Z";
                }
                // pub
                if(map[j][i].type == 2)
                {
                    table[i][j+1] = "P";
                }
                // library
                if(map[j][i].type == 4)
                {
                    table[i][j+1] = "⌂";
                }
            }
        }

        // students
        for (int i = 0; i < Student_list.size(); i++) {
            //table[Student_list.get(i).localization[0]][Student_list.get(i).localization[1]] = "☺";
            //System.out.println("s:"+i+" "+Student_list.get(i).localization[0]+" "+Student_list.get(i).localization[1]);
        }

        // chavs
        for (int i = 0; i < Chav_list.size(); i++) {
            //table[Chav_list.get(i).localization[0]][Chav_list.get(i).localization[1]] = "☻";
            //System.out.println("c:"+i+" "+Chav_list.get(i).localization[0]+" "+Chav_list.get(i).localization[1]);
        }

        return(table);

    }

}
