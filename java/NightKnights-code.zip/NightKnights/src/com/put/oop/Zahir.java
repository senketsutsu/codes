package com.put.oop;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Semaphore;

/**
 *
 * Zahir is a place serving kebabs, which Students can eat when they feel hungry (their food_level is low).
 * The employees of Zahir are not so good at multitasking, that's why only one person can eat each round.
 * But the rest of them can stand in a queue (lets say that there ca be at maximum of 100 people inside), but they still get more hungry each round.
 * Kebabs are very nutritious, so only one is enough to be full.
 */

public class Zahir extends Pixel{
    List<Student> queue;

    Zahir(int x, int y)
    {
        super(x,y);
        type = 1;
        queue = new ArrayList<Student>();
        empty.set(true);
        name = "Zahir";
        semaphore = new Semaphore(100);
    }

    public void add(Student id){
        queue.add(id);
        System.out.println(id.id+" added to the kebab queue");
    }

    public List<Student> queue()
    {
        return queue;
    }

    @Override
    public void paint(Graphics g)
    {
        g.setColor(new Color(94, 162, 112, 255));
        g.fillRect(this.localization[0]*5,this.localization[1]*5,5,5);
    }

    public String[] introduce_data(){
        String[] introduction = {String.valueOf(localization[0]),String.valueOf(localization[1]),String.valueOf(queue.size())};
        //System.out.print(introduction);
        return introduction;

    }
}
