package com.put.oop;

import org.w3c.dom.css.Rect;

import java.awt.*;
import java.util.Random;
import java.lang.Thread;

/**
 *
 * Chav represents the predator in this environment.<br>
 *
 * They have two extra attributes:<br>
 * - mode (hunting mode (true) / relax mode (false))<br>
 * - eyeshot (how far afar can they see the pray (Student) )<br>
 * - map<br>
 * - vx, vy (which way are they going)<br>
 * - body_count (how many Students they killed)<br>
 *
 * When they are in the hunting mode they look for a pray and when they see it they jump to it and fight.
 */

public class Chav extends Person implements Hunter, Runnable{
    boolean mode;
    int eyeshot;
    Map map;
    int vx, vy;
    int body_count;


    Chav(int ID, int Health, int Speed, int Strength, int x, int y, int Range, int Eyeshot, Map mapa)
    {
        super(ID, Health, Speed, Strength, x, y, Range);
        mode = true;
        eyeshot = Eyeshot;
        Random rand = new Random();
        vx = rand.nextInt(3)-1;
        vy = rand.nextInt(3)-1;
        map = mapa;
        body_count = 0;

    }
     public Boolean hunt(Student p2, Map mapa, int count){

        if(this.mode == false)
        {
            return false;
        }
        Rectangle per1 = new Rectangle(p2.localization[0],p2.localization[1],5,5);

        Rectangle per2 = new Rectangle(Math.max((this.localization[0]-this.eyeshot)*5, 0),Math.max((this.localization[1]-this.eyeshot)*5, 0),(5*(2*this.eyeshot+1)),(5*(2*this.eyeshot+1)));

        if(per1.intersects(per2))
        {
            System.out.println("Hunting id:"+p2.id);
            if(p2.safe == false)
            {
                this.localization[0] = p2.localization[0];
                this.localization[1] = p2.localization[1];

                System.out.println("Fighting id:"+p2.id);

                if(this.strength>p2.strength)
                {

                    p2.health -= (this.strength - p2.strength);
                    System.out.println("Won over id:"+p2.id+" health:"+p2.health+"/10");
                    if(p2.health <= 0)
                    {
                        System.out.println("Killed id:"+p2.id);
                        this.mode = false;
                        count = -1;
                        body_count++;
                        p2.safe = true;
                        // stop p2 student thread
                        //mapa.Student_list.remove(p2);
                        return true;
                    }
                }
            }
        }
        return false;

    }

    @Override
    public void paint(Graphics g)
    {
        if (mode==true)
        {
            g.setColor(new Color(217, 76, 33));
        }
        else {
            g.setColor(new Color(217, 174, 33));
        }

        g.fillOval(this.localization[0]*5,this.localization[1]*5,5,5);
    }

    @Override
    public void run() {
        Random rand = new Random();
        exit.set(true);
        int count = 0;

        while(exit.get())
        {

            if (!mode)
            {
                if (rand.nextInt(1000)<=10)
                {
                    mode = true;
                }
            }

            localization[0] = Math.min(Math.max((localization[0]+vx),0),range-1);
            localization[1] = Math.min(Math.max((localization[1]+vy),0),range-1);

            if(localization[0] <= 0 || localization[0] >= range-1)
            {
                vx *= -1;
            }

            if(localization[1] <= 0 || localization[1] >= range-1)
            {
                vy *= -1;
            }

            if(rand.nextInt(100)%3==0)
            {
                vx = rand.nextInt(3)-1;
                vy = rand.nextInt(3)-1;
            }

            try {
                Thread.sleep(Long.valueOf(speed*5));
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            for (int i = 0; i < map.Student_list.size(); i++) {
                hunt(map.Student_list.get(i),map, count);
            }

            try {
                Thread.sleep(Long.valueOf(speed*5));
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

        }
    }

    public void stop()
    {
        exit.set(false);
    }

    public String[] introduce_data(){
        String[] introduction = {String.valueOf(id),name,String.valueOf(localization[0]),String.valueOf(localization[1]),String.valueOf(health),String.valueOf(mode),String.valueOf(eyeshot),String.valueOf(body_count),String.valueOf(speed),String.valueOf(strength),zodiac_sign};
        //System.out.print(introduction);
        return introduction;

    }

}
