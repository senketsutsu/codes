package com.put.oop;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumnModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;


public class app extends JFrame{
    private JPanel MainPanel;
    private JLabel JTitle;
    private JLabel StudentLabel;
    private JTextField StudentsNumber;
    private JTextField ChavNumber;
    private JTextField MapSize;
    private JButton STARTButton;
    private JTable MapView;
    private JPanel RightPanel;
    private JPanel LeftPanel;
    private JPanel ImputPanel;
    private JScrollPane TablePanel;
    private JTextPane thisMapShowsTheTextPane;
    private JScrollPane DataTable;
    private JPanel ControllPanell;
    private JLabel TypeLabel;
    private JComboBox TypeComboBox;
    private JTable TableData;
    private JPanel ExtraPanel;
    private JTextField textField1;
    private JButton ChangeButton;
    private JTextField textField2;
    private JButton DelButton;

    Map Map_visualisation;
    MPanel visualization;

    public app(String title)
    {
        super(title);


        // Generate table showing current data about objects
        String s1[]={"Chav","Library","Pub","Student","Zahir"};

        TypeComboBox.setModel(new DefaultComboBoxModel(s1));
        TypeComboBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JComboBox cb = (JComboBox)e.getSource();
                String TypeName = (String)cb.getSelectedItem();

                List<String[]> data = get_data(TypeName);
                String[] colName = data.get(0);
                data.remove(0);
                String[][] tabData = new String[data.size()][colName.length];
                for (int i = 0; i < data.size(); i++) {
                    tabData[i] = data.get(i);
                }

                TableData.setModel(new DefaultTableModel(tabData,colName));
            }
        });

        MapView.setModel(new DefaultTableModel(null,new String[]{"Set", "the", "values", "under", "the", "title"}));


        // Change the route of Student with given id
        ChangeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int id = (int)(Double.parseDouble(textField1.getText()));

                //System.out.println("\n!!! ID: "+id+"\n");

                for (int i = 0; i < Map_visualisation.Student_list.size(); i++) {
                    if (Map_visualisation.Student_list.get(i).id==id)
                    {
                        //System.out.print("from "+Map_visualisation.Student_list.get(i).destination);
                        Map_visualisation.Student_list.get(i).change_destination(new Random());
                        //System.out.println(" to "+Map_visualisation.Student_list.get(i).destination);
                    }
                }
            }
        });

        // Remove person with given id
        DelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int id = (int)(Double.parseDouble(textField2.getText()));

                for (int i = 0; i < Map_visualisation.Student_list.size(); i++) {
                    if (Map_visualisation.Student_list.get(i).id==id)
                    {
                        Map_visualisation.Student_list.get(i).health-=10;
                    }
                }
                for (int i = 0; i < Map_visualisation.Chav_list.size(); i++) {
                    if (Map_visualisation.Chav_list.get(i).id==id)
                    {
                        Map_visualisation.Chav_list.get(i).health-=10;
                    }
                }
        }});

        // Create table map
        STARTButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // take the value from StudentsNumber, ChavNumber, MapSize
                int sNum, cNum, mNum;
                sNum = (int)(Double.parseDouble(StudentsNumber.getText()));
                cNum = (int)(Double.parseDouble(ChavNumber.getText()));
                mNum = (int)(Double.parseDouble(MapSize.getText()));

                // start the whole program
                Map_visualisation = new Map(mNum,sNum,cNum);
                Map mapViewer = Map_visualisation;

                // START generate map
                String[][] mapData = mapViewer.generate_table();
                String[] columnNames = new String[mNum+1];
                columnNames[0] = "";
                for (int i = 1; i < mNum+1; i++) {
                    columnNames[i] = Integer.toString(i);
                }
                MapView.setModel(new DefaultTableModel(mapData,columnNames));
                MapView.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
                MapView.setRowHeight(15);
                TableColumnModel columnModel = MapView.getColumnModel();
                for (int i = 0; i < mNum+1; i++) {
                    columnModel.getColumn(i).setPreferredWidth(17);
                }
                MapView.getTableHeader().setFont(new Font(null,Font.PLAIN,12));
                // END generate map

                visualization = new MPanel(mNum,Map_visualisation);


            }
        });
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setContentPane(MainPanel);
        this.pack();
    }


    public static void main(String[] args)
    {
        JFrame frame = new app("Night Knights");
        frame.pack();
        frame.setVisible(true);
    }

    public List<String[]> get_data(String type)
    {
        List<String[]> data;
        switch (type)
        {
            case "Chav":
                data = new ArrayList<String[]>();
                data.add(new String[]{"ID","name","x","y","health","mode","eyeshot","body count","speed","strength","zodiac sign"});
                for (int i = 0; i < Map_visualisation.Chav_list.size(); i++) {
                    data.add(Map_visualisation.Chav_list.get(i).introduce_data());
                }

                return data;
            case "Library":
                data = new ArrayList<String[]>();
                data.add(new String[]{"x","y","available space"});
                for (int i = 0; i < Map_visualisation.Libraries.size(); i++) {
                    data.add(Map_visualisation.Libraries.get(i).introduce_data());
                }

                return data;
            case "Pub":
                data = new ArrayList<String[]>();
                data.add(new String[]{"x","y","how hydrating","available space"});
                for (int i = 0; i < Map_visualisation.Pubs.size(); i++) {
                    data.add(Map_visualisation.Pubs.get(i).introduce_data());
                }

                return data;
            case "Student":
                data = new ArrayList<String[]>();
                data.add(new String[]{"ID","name","x","y","health","beer level","food level","speed","strength","safe","zodiac sign"});
                for (int i = 0; i < Map_visualisation.Student_list.size(); i++) {
                    data.add(Map_visualisation.Student_list.get(i).introduce_data());
                }

                return data;
            case "Zahir":
                data = new ArrayList<String[]>();
                data.add(new String[]{"x","y","queue length"});
                for (int i = 0; i < Map_visualisation.Zahirs.size(); i++) {
                    data.add(Map_visualisation.Zahirs.get(i).introduce_data());
                }

                return data;
        }
        return new ArrayList<String[]>();
    }
}
