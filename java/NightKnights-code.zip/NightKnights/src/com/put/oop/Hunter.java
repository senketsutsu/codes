package com.put.oop;

/**
 * Interface allowing Hunters to hunt Preys.
 */

interface Hunter {
    public Boolean hunt(Student p2, Map mapa, int count);
}
