package com.put.oop;
import java.awt.*;
import java.util.Random;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 *
 * Person represents everyone, no matter if they are prey and predator.<br>
 * Each person has:<br>
 * - id (a unique identification number)<br>
 * - name<br>
 * - health (health level, which indicates how far from death are they)<br>
 * - speed (how long it has to wait between steps (the smaller, the faster)(numbers are in ms.))<br>
 * - strength (strength is important when it comes to fighting, the stronger the Person the more likely they survive)<br>
 * - zodiac_sign (indicates what type of person they are)<br>
 * - localization ( (x,y) localization in the map)<br>
 * - exit (tells if current thread should be stopped)<br>
 * - range (size of map used for walking so that the people don't go outside the map)<br>
 *
 *
 */

public class Person {
    int id;
    String name;
    int health;
    int speed;
    int strength;
    String zodiac_sign;
    int[] localization;
    AtomicBoolean exit = new AtomicBoolean(false);
    int range;


    Person(int ID, int Health, int Speed, int Strength, int x, int y, int Range)
    {
        exit.set(false);
        range = Range;
        id = ID;
        name = generate_name();
        health = Health;
        speed = Speed;
        strength = Strength;
        Random rand = new Random();
        String[] signs = {"Aries", "Taurus", "Gemini", "Cancer", "Leo", "Virgo", "Libra", "Scorpio", "Sagittarius", "Capricorn", "Aquarius", "Pisces"};
        zodiac_sign = signs[rand.nextInt(signs.length)];
        localization = new int[2];
        localization[0] = x;
        localization[1] = y;
    }

    private String generate_name(){
        Random rand = new Random();

        String[] names = {"Abigail" , "Ace" , "Amos" , "Augie" , "Barkley" , "Ben" , "Gus" , "Heidi" , "Hunter" , "Jamie" , "Jetta" , "Misty" , "Pearl" , "Silver"};
        String[] lastnames = {"Nowak", "Kowalski", "Kowalczyk" ,"Lewandowski", "Wojcik", "Kaminski", "Zielinski" };
        String name = names[rand.nextInt(names.length)] + " " + lastnames[rand.nextInt(lastnames.length)];

        return name;
    }

    public void walk(){
        System.out.println("Walking");
    }

    public void fight(){
        System.out.println("Fighting");
    }

    public String introduce(){
        String introduction = "ID: "+id+"\nName: "+name+"\nHealth: "+health+"/10\nSpeed: "+speed+"\nStrength: "+strength+"\nZodiac sign: "+zodiac_sign+"\n";
        System.out.print(introduction);
        return introduction;
    }

    public String[] introduce_data(){
        String[] introduction = {String.valueOf(id),name,String.valueOf(localization[0]),String.valueOf(localization[1]),String.valueOf(health),String.valueOf(speed),String.valueOf(strength),zodiac_sign};
        //System.out.print(introduction);
        return introduction;

    }

    public void paint(Graphics g)
    {
        g.setColor(new Color(160,160,160));
        g.fillOval(this.localization[0]*5,this.localization[1]*5,5,5);
    }

}
