package com.put.oop;

import java.awt.*;
import java.util.concurrent.Semaphore;

/**
 *
 * Pub is a place where Students can drink beer.<br>
 * Each Pub has different kind of beer and because of that it has its
 * hydrating indicator (how_hydrating) which shows how fast can a Student
 * be hydrated when drinking this beer.
 *
 */

public class Pub extends Pixel{
    int how_hydrating;

    Pub(int x, int y, int How_hydrating)
    {
        super(x,y);
        type = 2;
        how_hydrating = How_hydrating;
        empty.set(true);
        name = "Pub";
        semaphore = new Semaphore(1+How_hydrating);
    }

    @Override
    public void paint(Graphics g)
    {
        g.setColor(new Color(111, 177, 197, 255));
        g.fillRect(this.localization[0]*5,this.localization[1]*5,5,5);
    }

    public void drink(Student a)
    {
        //System.out.println(a.id+": "+a.beer_level+" -> "+(a.beer_level+how_hydrating));
        a.beer_level= Math.ceil(Math.min(a.beer_level+how_hydrating, 100.0));
    }

    public String[] introduce_data(){
        String[] introduction = {String.valueOf(localization[0]),String.valueOf(localization[1]),String.valueOf(how_hydrating),String.valueOf(semaphore.availablePermits())};
        //System.out.print(introduction);
        return introduction;

    }
}
