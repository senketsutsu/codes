package com.put.oop;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 *
 * MPanel (Map Panel) visualizes (paints) the objects on a map in real-time.
 *
 */

public class MPanel extends JPanel implements ActionListener {
    Map mapViewer;
    int size;
    int s = 1;

    public MPanel(int Size, Map Map){
        mapViewer = Map;
        size = Size;

        JFrame frame = new JFrame("Map");
        frame.setSize(((size*5)+5),((size*5)+5));
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        Timer t = new Timer(16,this);
        t.restart();
        System.out.println(mapViewer.Path_list.size());

        frame.add(this);
        frame.setVisible(true);

    }

    public void paint(Graphics g)
    {

        super.paintComponent(g);
        //g.fillOval(10,10,s,100);
        //s++;

        for (int i = 0; i < mapViewer.Path_list.size(); i++) {
            mapViewer.Path_list.get(i).paint(g);
        }

        for (int i = 0; i < mapViewer.Chav_list.size(); i++) {
            mapViewer.Chav_list.get(i).paint(g);
        }

        for (int i = 0; i < mapViewer.Pubs.size(); i++) {
            mapViewer.Pubs.get(i).paint(g);
        }

        for (int i = 0; i < mapViewer.Zahirs.size(); i++) {
            mapViewer.Zahirs.get(i).paint(g);
        }

        for (int i = 0; i < mapViewer.Libraries.size(); i++) {
            mapViewer.Libraries.get(i).paint(g);
        }

        for (int i = 0; i < mapViewer.Student_list.size(); i++) {
            mapViewer.Student_list.get(i).paint(g);
        }

        int k = mapViewer.Student_list.size()-1;
        int j = 0;
        while(k>=0)
        {
            if(mapViewer.Student_list.get(j).health<=0)
            {
                mapViewer.Student_list.get(j).stop();
                mapViewer.Student_list.remove(j);
                j--;
                System.out.println(mapViewer.Student_list.size());
            }
            k--;
            j++;
        }

        k = mapViewer.Chav_list.size()-1;
        j = 0;
        while(k>=0)
        {
            if(mapViewer.Chav_list.get(j).health<=0)
            {
                mapViewer.Chav_list.get(j).stop();
                mapViewer.Chav_list.remove(j);
                j--;
                System.out.println(mapViewer.Chav_list.size());
            }
            k--;
            j++;
        }

        for (int i = 0; i < mapViewer.Zahirs.size(); i++) {
            if(mapViewer.Zahirs.get(i).queue().size()!=0)
            {
                System.out.println("eating "+mapViewer.Zahirs.get(i).queue().get(0).id);
                mapViewer.Zahirs.get(i).queue().get(0).eat();
                mapViewer.Zahirs.get(i).queue().remove(0);
            }
        }

    }

    public static void main(String[] arg)
    {
        MPanel c = new MPanel(50,new Map(100,50,50));
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        repaint();
    }
}
